package zikcam.member.login;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/member")
public class MemberLoginController {
	
	@Resource(name="memberLoginService")
	private MemberLoginService memberLoginService;
	
	Logger log = Logger.getLogger(this.getClass());
	
	//login
	
	@RequestMapping(value="/login", method = RequestMethod.GET)
	public String login(Model model) {
		return "/login";
	}
	
	@RequestMapping(value="/findID", method = RequestMethod.GET)
	public String findID(Model model) {
		return "/findID";
	}
	
	@RequestMapping(value="/findPW", method = RequestMethod.GET)
	public String findPW(Model model) {
		return "/findPW";
	}
	
}