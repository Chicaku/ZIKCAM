package zikcam.member.login;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import zikcam.common.dao.AbstractDAO;

@Repository("memberLoginDAO")
public class MemberLoginDAO extends AbstractDAO {
	Logger log = Logger.getLogger(this.getClass());

}