package zikcam.member.login;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

@Service("memberLoginService")
public class MemberLoginService {
	Logger log = Logger.getLogger(this.getClass());
	
	@Resource(name="memberLoginDAO")
	private MemberLoginDAO memberLoginDAO;
}