package zikcam.member.join;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

@Service("memberJoinService")
public class MemberJoinService {
	Logger log = Logger.getLogger(this.getClass());
	
	@Resource(name="memberJoinDAO")
	private MemberJoinDAO memberJoinDAO;
}