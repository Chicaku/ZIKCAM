package zikcam.member.join;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/member")
public class MemberJoinController {
	
	@Resource(name="memberJoinService")
	private MemberJoinService memberJoinService;
	
	Logger log = Logger.getLogger(this.getClass());
	
	//login
	
	@RequestMapping(value="/join", method = RequestMethod.GET)
	public String join(Model model) {
		return "/join";
	}
	
	@RequestMapping(value="/agreement", method = RequestMethod.GET)
	public String agreement(Model model) {
		return "/agreement";
	}
	
}