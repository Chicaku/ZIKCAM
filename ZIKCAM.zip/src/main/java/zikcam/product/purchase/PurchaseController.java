package zikcam.product.purchase;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/prod")
public class PurchaseController {
	
	@Resource(name="purchaseService")
	private PurchaseService purchaseService;
	
	Logger log = Logger.getLogger(this.getClass());
	
	//purchase
	@RequestMapping(value="/main", method = RequestMethod.GET)
	public String main(Model model) {
		return "/main";
	}
	
	@RequestMapping(value="/purchaseTent", method = RequestMethod.GET)
	public String purchaseTent(Model model) {
		return "/purchaseTent";
	}
	
	@RequestMapping(value="/purchaseMatt", method = RequestMethod.GET)
	public String purchaseMatt(Model model) {
		return "/purchaseMatt";
	}
	
	@RequestMapping(value="/purchaseTable", method = RequestMethod.GET)
	public String purchaseTable(Model model) {
		return "/purchaseTable";
	}
	
	@RequestMapping(value="/purchaseEtc", method = RequestMethod.GET)
	public String purchaseEtc(Model model) {
		return "/purchaseEtc";
	}
	
}