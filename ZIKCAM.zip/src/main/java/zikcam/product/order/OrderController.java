package zikcam.product.order;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/prod")
public class OrderController {
	
	@Resource(name="orderService")
	private OrderService orderService;
	
	Logger log = Logger.getLogger(this.getClass());
	
	
	//order
	@RequestMapping(value="/order", method = RequestMethod.GET)
	public String order(Model model) {
		return "/order";
	}
	
	@RequestMapping(value="/orderPay", method = RequestMethod.GET)
	public String orderPay(Model model) {
		return "/orderPay";
	}
	
	@RequestMapping(value="/orderPaySuccess", method = RequestMethod.GET)
	public String orderPaySuccess(Model model) {
		return "/orderPaySuccess";
	}
	
	@RequestMapping(value="/orderPayFail", method = RequestMethod.GET)
	public String orderPayFail(Model model) {
		return "/orderPayFail";
	}
}