package zikcam.myPage.myAccount.controller;


import java.util.List;
import java.util.Map;


import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import zikcam.common.map.CommandMap;
import zikcam.myPage.myAccount.service.MyAccountService;

@Controller
@RequestMapping("/myPage")
public class MyAccountController {

	Logger log = Logger.getLogger(this.getClass());
	
	@Resource(name = "myAccountService")
	private MyAccountService myAccountService;
	
	//myAccount
	
	@RequestMapping(value = "/myAccount")
	public ModelAndView openmyAccount(Map<String, Object> commandMap) throws Exception {
		ModelAndView mv = new ModelAndView("/myAccount");
		System.out.println(log.isDebugEnabled());
		log.debug("인터셉터");
		List<Map<String, Object>> list = myAccountService.selectAccount(commandMap);
		mv.addObject("list", list);
		return mv;
	}
	
	
	@RequestMapping(value="/myAccountModifyForm", method = RequestMethod.GET)
	public ModelAndView myAccountModifyForm(CommandMap commandMap) throws Exception {
		ModelAndView mv = new ModelAndView("/myAccountModify");
		
		Map<String, Object> map = myAccountService.selectAccountModify(commandMap.getMap());
		mv.addObject("map", map);
		return mv;
	}
	
	@RequestMapping(value = "/myAccountModify", method = RequestMethod.POST)
	public ModelAndView myAccountModify(CommandMap commandMap) throws Exception{
		ModelAndView mv = new ModelAndView("redirect:/myPage/myAccount");
		
		System.out.println(commandMap.getMap());
		myAccountService.updateAccount(commandMap.getMap());
//		mv.addObject("MEMBER_NUM", commandMap.get("MEMBER_NUM"));

		return mv;
	}
	
	@RequestMapping(value="/myAccountPwCheck")
	public ModelAndView myAccountPwCheck(CommandMap commandMap) throws Exception{
		ModelAndView mv = new ModelAndView("/myAccountPwCheck");
		
		Map<String, Object> map = myAccountService.selectAccountModify(commandMap.getMap());
		mv.addObject("map", map);
		
		return mv;
	}
	
	
	
}
