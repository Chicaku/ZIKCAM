package zikcam.myPage.myCart.dao;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import zikcam.common.dao.AbstractDAO;

@Repository("myCartDAO")
public class MyCartDAO extends AbstractDAO {
	Logger log = Logger.getLogger(this.getClass());

	@SuppressWarnings("unchecked")
	public List<Map<String, Object>> selectCartBuyingList(Map<String, Object> map) throws Exception{
		return (List<Map<String, Object>>) selectList("mypage.selectCartBuyingList", map); 
	}
	@SuppressWarnings("unchecked")
	public List<Map<String, Object>> selectCartRentalList(Map<String, Object> map) throws Exception{
		return (List<Map<String, Object>>) selectList("mypage.selectCartRentalList", map); 
	}
	@SuppressWarnings("unchecked")
	public List<Map<String, Object>> selectCartBuyingPrice(Map<String, Object> map) throws Exception{
		return (List<Map<String, Object>>) selectList("mypage.selectCartBuyingPrice", map); 
	}
	@SuppressWarnings("unchecked")
	public List<Map<String, Object>> selectCartRentalPrice(Map<String, Object> map) throws Exception{
		return (List<Map<String, Object>>) selectList("mypage.selectCartRentalPrice", map); 
	}
}