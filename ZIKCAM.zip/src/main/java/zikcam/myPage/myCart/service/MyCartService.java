package zikcam.myPage.myCart.service;

import java.util.List;
import java.util.Map;


public interface MyCartService {
	
	
	List<Map<String, Object>> selectCartBuyingList(Map<String, Object> commandMap) throws Exception;
	List<Map<String, Object>> selectCartBuyingPrice(Map<String, Object> commandMap) throws Exception;
	List<Map<String, Object>> selectCartRentalList(Map<String, Object> commandMap) throws Exception;
	List<Map<String, Object>> selectCartRentalPrice(Map<String, Object> commandMap) throws Exception;
}