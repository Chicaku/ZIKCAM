package zikcam.myPage.myCart.service;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import zikcam.myPage.myCart.dao.MyCartDAO;

@Service("myCartService")
public class MyCartServiceImpl implements MyCartService{
	
Logger log = Logger.getLogger(this.getClass());
	
	@Resource(name="myCartDAO")
	private MyCartDAO myCartDAO;
	
	@Override
	public List<Map<String, Object>> selectCartBuyingList(Map<String, Object> map) throws Exception{
		return myCartDAO.selectCartBuyingList(map);
	}
	@Override
	public List<Map<String, Object>> selectCartRentalList(Map<String, Object> map) throws Exception{
		return myCartDAO.selectCartRentalList(map);
	}
	@Override
	public List<Map<String, Object>> selectCartBuyingPrice(Map<String, Object> map) throws Exception{
		return myCartDAO.selectCartBuyingPrice(map);
	}
	@Override
	public List<Map<String, Object>> selectCartRentalPrice(Map<String, Object> map) throws Exception{
		return myCartDAO.selectCartRentalPrice(map);
	}
}
