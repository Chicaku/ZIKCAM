package zikcam.myPage.myCart.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import zikcam.common.map.CommandMap;
import zikcam.myPage.myCart.service.MyCartService;


@Controller
@RequestMapping("/myPage")
public class MyCartController {
	
	@Resource(name="myCartService")
	private MyCartService myCartService;
	
	Logger log = Logger.getLogger(this.getClass());
	
	
	//myCart
	@RequestMapping(value="/myCartList")
	public ModelAndView openCartList(Map<String, Object> commandMap) throws Exception{
		ModelAndView mv = new ModelAndView("/myCartList");
		
		List<Map<String, Object>> buyinglist = myCartService.selectCartBuyingList(commandMap);
		List<Map<String, Object>> rentallist = myCartService.selectCartRentalList(commandMap);
		List<Map<String, Object>> buyingprice = myCartService.selectCartBuyingPrice(commandMap);
		List<Map<String, Object>> rentalprice = myCartService.selectCartRentalPrice(commandMap);
		mv.addObject("buyinglist", buyinglist);
		mv.addObject("rentallist", rentallist);
		mv.addObject("buyingprice", buyingprice);
		mv.addObject("rentalprice", rentalprice);
		
		return mv;
	}
	
	@RequestMapping(value = "/myCartPartDelete")
	public ModelAndView myCartPartDelete(CommandMap commandMap) throws Exception{
		ModelAndView mv = new ModelAndView("redirect:/mypage/myOrderList");
		
		System.out.println(commandMap.getMap());
		return mv;
	}
}
