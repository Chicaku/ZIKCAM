package zikcam.adminPage.product;

import java.util.List;
import java.util.Map;

public interface AdminProductService {

	List<Map<String, Object>> adProductList(Map<String, Object> map, String keyword, String searchType)throws Exception;

	Map<String, Object> adProductModify(Map<String, Object> map);
}
