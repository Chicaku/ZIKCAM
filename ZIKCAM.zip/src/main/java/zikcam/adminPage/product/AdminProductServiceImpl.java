package zikcam.adminPage.product;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

@Service("adminProductService")
public class AdminProductServiceImpl implements AdminProductService {
	Logger log = Logger.getLogger(this.getClass());
	
	@Resource(name="adminProductDAO")
	private AdminProductDAO adminProductDAO;

	@Override
	public List<Map<String, Object>> adProductList(Map<String, Object> map, String keyword, String searchType) throws Exception {
		map.put("keyword", keyword); 
		map.put("searchType", searchType);
		
		if(keyword.equals("") || keyword == null) {
			return adminProductDAO.adProductList(map);
		}else {
			return adminProductDAO.adProductSearchList(map);
		}
		
	}

	@Override
	public Map<String, Object> adProductModify(Map<String, Object> map) {
		Map<String, Object> resultMap = adminProductDAO.adProductModify(map);
		return resultMap;
	}
	
}