package zikcam.customerService.qna;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/cs")
public class CSQnAController {

	@Resource(name="csQnAService")
	private CSQnAService csQnAService;
	
	Logger log = Logger.getLogger(this.getClass());
	
	
	//qna
	
	@RequestMapping(value="/qnaList", method = RequestMethod.GET)
	public String qnaList(Model model) {
		return "/qnaList";
	}
	
	@RequestMapping(value="/qnaDetail", method = RequestMethod.GET)
	public String qnaDetail(Model model) {
		return "/qnaDetail";
	}
	
	@RequestMapping(value="/qnaWrite", method = RequestMethod.GET)
	public String qnaWrite(Model model) {
		return "/qnaWrite";
	}
	
	@RequestMapping(value="/qnaModify", method = RequestMethod.GET)
	public String qnaModify(Model model) {
		return "/qnaModify";
	}
	
	@RequestMapping(value="/qnaDelete", method = RequestMethod.GET)
	public String qnaDelete(Model model) {
		return "/qnaDelete";
	}
	
}
