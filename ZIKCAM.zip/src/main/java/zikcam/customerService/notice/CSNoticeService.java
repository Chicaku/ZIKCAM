package zikcam.customerService.notice;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

@Service("csNoticeService")
public class CSNoticeService {
	Logger log = Logger.getLogger(this.getClass());
	
	@Resource(name="csNoticeDAO")
	private CSNoticeDAO csNoticeDAO;
}