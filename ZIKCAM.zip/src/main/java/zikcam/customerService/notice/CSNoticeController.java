package zikcam.customerService.notice;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/cs")
public class CSNoticeController {

	@Resource(name="csNoticeService")
	private CSNoticeService csNoticeService;
	Logger log = Logger.getLogger(this.getClass());
	
	//notice
	
	@RequestMapping(value="/noticeList", method = RequestMethod.GET)
	public String noticeList(Model model) {
		return "/noticeList";
	}
	
	@RequestMapping(value="/noticeDetail", method = RequestMethod.GET)
	public String noticeDetail(Model model) {
		return "/noticeDetail";
	}
	
	@RequestMapping(value="/noticeWrite", method = RequestMethod.GET)
	public String noticeWrite(Model model) {
		return "/noticeWrite";
	}
	
	@RequestMapping(value="/noticeModify", method = RequestMethod.GET)
	public String noticeModify(Model model) {
		return "/noticeModify";
	}
	
	@RequestMapping(value="/noticeDelete", method = RequestMethod.GET)
	public String noticeDelete(Model model) {
		return "/qnaDelete";
	}
}
