package zikcam.customerService.faq;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/cs")
public class CSFAQController {


	@Resource(name="csFAQService")
	private CSFAQService csFAQService;
	
	Logger log = Logger.getLogger(this.getClass());
	
	
	//faq
	
	@RequestMapping(value="/faqList", method = RequestMethod.GET)
	public String faqList(Model model) {
		return "/faqList";
	}
	
	@RequestMapping(value="/faqWrite", method = RequestMethod.GET)
	public String faqWrite(Model model) {
		return "/faqWrite";
	}
	
	@RequestMapping(value="/faqModify", method = RequestMethod.GET)
	public String faqModify(Model model) {
		return "/faqModify";
	}
	
}